import json

DATA_FILE = "students.json"

def load_data():
    try:
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    except:
        return []

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)

def calculate_result(marks):
    total = sum(marks)
    percentage = total / len(marks)

    if percentage >= 75:
        grade = "A"
    elif percentage >= 60:
        grade = "B"
    elif percentage >= 40:
        grade = "C"
    else:
        grade = "Fail"

    return total, percentage, grade

def add_student(data):
    name = input("Enter student name: ")
    roll = input("Enter roll number: ")

    marks = []
    for i in range(3):
        mark = float(input(f"Enter subject {i+1} marks: "))
        marks.append(mark)

    total, percentage, grade = calculate_result(marks)

    student = {
        "name": name,
        "roll": roll,
        "marks": marks,
        "total": total,
        "percentage": percentage,
        "grade": grade
    }

    data.append(student)
    save_data(data)
    print("Student added successfully!\n")

def view_students(data):
    if not data:
        print("No records found.\n")
        return

    for s in data:
        print("\n-------------------")
        print(f"Name: {s['name']}")
        print(f"Roll: {s['roll']}")
        print(f"Marks: {s['marks']}")
        print(f"Total: {s['total']}")
        print(f"Percentage: {s['percentage']:.2f}")
        print(f"Grade: {s['grade']}")
        print("-------------------")

def menu():
    data = load_data()

    while True:
        print("\n===== Student Result System =====")
        print("1. Add Student")
        print("2. View Students")
        print("3. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            add_student(data)
        elif choice == "2":
            view_students(data)
        elif choice == "3":
            break
        else:
            print("Invalid choice!")

menu()