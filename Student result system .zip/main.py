# Student Result Management System

students = []

def calculate_result(marks):
    total = sum(marks)
    percentage = total / len(marks)

    if percentage >= 75:
        grade = "A"
    elif percentage >= 60:
        grade = "B"
    elif percentage >= 40:
        grade = "C"
    else:
        grade = "Fail"

    return total, percentage, grade


def add_student():
    name = input("Enter student name: ")
    roll = input("Enter roll number: ")

    marks = []
    for i in range(3):
        m = float(input(f"Enter subject {i+1} marks: "))
        marks.append(m)

    total, percentage, grade = calculate_result(marks)

    student = {
        "name": name,
        "roll": roll,
        "marks": marks,
        "total": total,
        "percentage": percentage,
        "grade": grade
    }

    students.append(student)
    print("Student added successfully!\n")


def view_students():
    if len(students) == 0:
        print("No records found.\n")
        return

    for s in students:
        print("\n-------------------")
        print(f"Name: {s['name']}")
        print(f"Roll: {s['roll']}")
        print(f"Marks: {s['marks']}")
        print(f"Total: {s['total']}")
        print(f"Percentage: {s['percentage']:.2f}")
        print(f"Grade: {s['grade']}")
        print("-------------------")


def menu():
    while True:
        print("\n===== Student Result System =====")
        print("1. Add Student")
        print("2. View Students")
        print("3. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            add_student()
        elif choice == "2":
            view_students()
        elif choice == "3":
            print("Exiting program...")
            break
        else:
            print("Invalid choice!")


menu()